import React from 'react';
import {View, Text} from 'react-native';

const HomePage = () => {

return (
  <view> 
  <Text> TrainerHub </Text>
  </view>

);

}

export default HomePage;