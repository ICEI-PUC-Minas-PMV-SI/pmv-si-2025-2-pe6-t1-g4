import React, { useState } from "react";
import { Alert } from "react-native";

import HomeScreen from "./src/HomeScreen";
import RegisterStep1 from "./src/RegisterStep1";
import RegisterStep2 from "./src/RegisterStep2";
import RegisterStep3 from "./src/RegisterStep3";

export default function App() {
  const [screen, setScreen] = useState("home");
  const [formData, setFormData] = useState({});

  // Navega para Step1 desde Home
  function goToStep1() {
    setScreen("step1");
  }

  // Step1 -> Step2
  function handleStep1Next(data) {
    setFormData((prev) => ({ ...prev, ...data }));
    setScreen("step2");
  }

  // Step2 -> Step3
  function handleStep2Next(data) {
    setFormData((prev) => ({ ...prev, ...data }));
    setScreen("step3");
  }

  // Step3 -> Finaliza e volta para Home
  function handleStep3Finish(data) {
    const allData = { ...formData, ...data };
    console.log("DADOS DO CADASTRO:", allData);

    Alert.alert("Sucesso", "Cadastro efetuado com sucesso!", [
      {
        text: "OK",
        onPress: () => {
          setScreen("home");
          setFormData({});
        },
      },
    ]);
  }

  // ======== RENDERIZAÇÃO DAS TELAS =========

  if (screen === "home") {
    return (
      <HomeScreen
        onPressRegister={goToStep1}
        // falta: onPressLogin={() => setScreen("login")}
      />
    );
  }

  if (screen === "step1") {
    return (
      <RegisterStep1
        onNext={handleStep1Next}
        onBack={() => setScreen("home")}
      />
    );
  }

  if (screen === "step2") {
    return (
      <RegisterStep2
        onNext={handleStep2Next}
        onBack={() => setScreen("step1")}
      />
    );
  }

  if (screen === "step3") {
    return (
      <RegisterStep3
        onFinish={handleStep3Finish}
        onBack={() => setScreen("step2")}
      />
    );
  }

  return null;
}
