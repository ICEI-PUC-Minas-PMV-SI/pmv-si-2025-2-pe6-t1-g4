// src/RegisterStep3.js
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from "react-native";

export default function RegisterStep3({ onFinish, onBack }) {
  const [genero, setGenero] = useState("");
  const [altura, setAltura] = useState("");
  const [peso, setPeso] = useState("");
  const [telefone, setTelefone] = useState("");

  function handleFinish() {
    if (!genero || !altura || !peso || !telefone) {
      Alert.alert("Atenção", "Preencha todos os campos.");
      return;
    }

    // devolve os dados para o App.js
    onFinish &&
      onFinish({
        genero,
        altura,
        peso,
        telefone,
      });
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View style={styles.content}>
        <Text style={styles.title}>Registrar</Text>

        <View style={styles.form}>
          <TextInput
            style={styles.input}
            placeholder="Gênero"
            placeholderTextColor="#777"
            value={genero}
            onChangeText={setGenero}
          />

          <TextInput
            style={styles.input}
            placeholder="Altura (cm)"
            placeholderTextColor="#777"
            value={altura}
            onChangeText={setAltura}
            keyboardType="numeric"
          />

          <TextInput
            style={styles.input}
            placeholder="Peso (kg)"
            placeholderTextColor="#777"
            value={peso}
            onChangeText={setPeso}
            keyboardType="numeric"
          />

          <TextInput
            style={styles.input}
            placeholder="Telefone"
            placeholderTextColor="#777"
            value={telefone}
            onChangeText={setTelefone}
            keyboardType="phone-pad"
          />

          <TouchableOpacity style={styles.button} onPress={handleFinish}>
            <Text style={styles.buttonText}>FINALIZAR</Text>
          </TouchableOpacity>

          {onBack && (
            <TouchableOpacity
              style={{ marginTop: 12, alignItems: "center" }}
              onPress={onBack}
            >
              <Text style={{ color: "#555" }}>Voltar</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 40,
  },
  title: {
    fontSize: 32,
    fontWeight: "600",
    marginBottom: 24,
    color: "#000000",
  },
  form: {
    gap: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: "#000000",
    borderRadius: 2,
    paddingHorizontal: 10,
    height: 48,
    fontSize: 16,
  },
  button: {
    marginTop: 24,
    backgroundColor: "#000000",
    height: 48,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonText: {
    color: "#FFFFFF",
    fontWeight: "600",
    fontSize: 16,
    letterSpacing: 1,
  },
});
